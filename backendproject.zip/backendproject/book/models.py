from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Book(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    id = models.CharField(max_length=200,primary_key=True)
    title=models.CharField(max_length=200,null=True)
    Author=models.CharField(max_length=200,null=True)
    Pagecount=models.IntegerField()

    def __str__(self):
        return str(self.title)

class Store(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    Books = models.ForeignKey(Book,null=True, on_delete=models.CASCADE)
    storename=models.CharField(max_length=200,null=True)
    storephone=models.CharField(max_length=200,null=True)
    storeaddress=models.CharField(max_length=200,null=True)
    date_created=models.DateTimeField(auto_now_add=True,null=True)
    
    def __str__(self):
        return str(self.storename)

