from attr import field
from django.forms import ModelForm
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class createuserform(UserCreationForm):
    class Meta:
        model=User
        fields=['username','password'] 

class createbookform(ModelForm):
    class Meta:
        model=Book
        fields='__all__'
        
class createstore(ModelForm):
    class Meta:
        model = Store
        fields  = '__all__'