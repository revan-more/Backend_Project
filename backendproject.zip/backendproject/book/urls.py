from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *

urlpatterns =[
    path('/', Inventroy,name = 'inv'),
    
    path('', home,name='home'),
    path('login/', loginPage,name='login'),
    path('addbook/', addbook,name='addbook'),
    path('addstore/', addStore,name='addstore'),
    path('book/', book,name='book'),
    path('update/<str:pk>/',updatebook,name='update'),
    path('delete/<str:pk>/',delete,name='delete'),
    path('register/', registerPage,name='register'),
    path('logout/', logoutPage,name='logout'),
]